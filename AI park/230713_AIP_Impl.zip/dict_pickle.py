import pickle

infile = open('USpresStatesDict.dat', 'rb')
countries = pickle.load(infile)
infile.close()




a = 1