
def func(p1, p2, p3=1, p4=2):
    pass

func(10, 20, p4=40)