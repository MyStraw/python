def simple_function():
    """
    This is a simple function
    """
    x = 1
    # return None
    return

help(simple_function)
print(simple_function.__doc__)

r = simple_function()
return_print = print('abc')
print(return_print)

a = max(12, 2)
print(a)

