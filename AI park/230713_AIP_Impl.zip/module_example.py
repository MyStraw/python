# import module_a
# import module_b
# print('a:', module_a.x)
# print('b:', module_b.x)

from module_a import *
from module_b import *

print(x) # 10? 20? 아님 더해서 30?

