a = 1
b = 2



d = 23
print(d)
ff = 2

print('Done')