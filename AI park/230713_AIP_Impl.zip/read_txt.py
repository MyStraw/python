infile = open('textfile.txt', 'r')

firstName = 'Jinsun'

for s in infile:
    pass    

print(s.rstrip())

infile.close()