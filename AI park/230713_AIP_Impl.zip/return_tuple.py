
def tmp():
    return 1, 2, 3

r1 = tmp()
v1, v2, v3 = tmp()

print(v1, v2, v3)