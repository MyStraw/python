import random

cnt = 0

for _ in range(10000000):
    # if random.choice(['H', 'T']) == 'H':
    if random.random() > 0.5:
        cnt += 1

print('Heads: {}'.format(cnt))