import random
import string

# list_alphabets = 'abcdefghijklmnopqrstuvwxyz'
list_alphabets = string.ascii_lowercase

# selected = random.sample(list_alphabets, 3)
# selected = random.choices(list_alphabets, k=3)

selected = [chr(random.randint(ord('A'), ord('Z'))) for _ in range(3)]


print(selected)