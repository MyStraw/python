def isAlpha(L):
    for i in range(len(L) - 1):
        if L[i] > L[i+1]:
            return False
    return True

def isAlphaRecursion(L):
    if len(L) <= 1:
        return True
    elif L[0] <= L[1]:
        return isAlphaRecursion(L[1:])
    else:
        return False

list_words1 = ['apple', 'banana', 'carrot']
list_words2 = ['zebra', 'zero', 'alpha']

# print(isAlpha(list_words1))
# print(isAlpha(list_words2))

print(isAlphaRecursion(list_words1))
print(isAlphaRecursion(list_words2))