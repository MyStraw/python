import rectangle

rect = rectangle.Rectangle()

# rect._Rectangle__secret
# rect.__secret

print("width: {}".format(rect.getWidth()))
# 하지말자 아래처럼
# print("width: {}".format(rect._width))


class noInit():
    def __init__(self, a, b):
        pass
    

o1 = noInit()

print('Done')