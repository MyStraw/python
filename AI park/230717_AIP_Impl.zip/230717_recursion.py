import sys
sys.setrecursionlimit(100)

def power(r, n):
    return r*power(r, n-1)
    # if n > 1:
    #     return r*power(r, n-1)
    # else:
    #     return r

print(power(2, 3))